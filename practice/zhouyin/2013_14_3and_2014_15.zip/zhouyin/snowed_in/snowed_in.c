#include <stdio.h>
#include <limits.h>
int main(void)
{
    unsigned int n, measure;
    unsigned int max = 0, min = UINT_MAX;
    int i;

    scanf("%u", &n);
    for (i = 0; i < n; i++) {
        scanf("%u", &measure);
        if (measure > max)
            max = measure;
        if (measure < min)
            min = measure;
    }

    printf("%u\n", max-min);
    return 0;
}
