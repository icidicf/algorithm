#include <stdio.h>
#include <ctype.h>

#define MAX_INPUT 5000
enum Poker {
    TWO,
    THREE,
    FOUR,
    FIVE,
    SIX,
    SEVEN,
    EIGHT,
    NINE,
    JACK,
    QUEEN,
    KING,
    ACE
};

static int getValue(char c) 
{
    switch(c) {
        case '2':
            return TWO;
        case '3':
            return THREE;
        case '4':
            return FOUR;
        case '5':
            return FIVE;
        case '6':
            return SIX;
        case '7':
            return SEVEN;
        case '8':
            return EIGHT;
        case '9':
            return NINE;
        case 'J':
            return JACK;
        case 'Q':
            return QUEEN;
        case 'K':
            return KING;
        case 'A':
            return ACE;
            
    }
}


int main(void)
{
    int n, i;
    char c;
    char playerOne[MAX_INPUT], playerTwo[MAX_INPUT];
    int valueOne, valueTwo;
    int playerOnePoint = 0 , playerTwoPoint = 0;

    scanf("%d",&n);
    for (i = 0; i < n ; i++) {
        do {
            scanf("%c", &c);
        } while (isalnum(c) == 0);
        playerOne[i] = c ;
    }

    for (i = 0; i < n ; i++) {
        do {
            scanf("%c", &c);
        } while (isalnum(c) == 0) ;
        playerTwo[i] = c ;
    }

    for (i = 0; i < n ; i++) {
        valueOne = getValue(playerOne[i]);
        valueTwo = getValue(playerTwo[i]);
        if (valueOne > valueTwo) {
            playerOnePoint++;
        }
        else if (valueOne < valueTwo) {
            playerTwoPoint++;
        } else {
        }
    }

    if (playerOnePoint > playerTwoPoint)
        printf("PLAYER 1 WINS\n");
    else if (playerOnePoint < playerTwoPoint)
        printf("PLAYER 2 WINS\n");
    else 
        printf("TIE\n");

    return 0;
}
