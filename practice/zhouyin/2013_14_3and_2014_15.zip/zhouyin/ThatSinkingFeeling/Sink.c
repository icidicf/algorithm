#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_INPUT 2000
typedef struct pair
{
    int x;
    int y;
} pair_t;

static swap(pair_t * A, pair_t *B)
{
    pair_t temp;
    temp.x = A->x;
    temp.y = A->y;

    A->x = B->x;
    A->y = B->y;

    B->x = temp.x;
    B->y= temp.y;
}

static getPoints(pair_t *ships, int ships_num, pair_t *fire)
{
    int i ;
    int score;
    int min_distance = 2*MAX_INPUT, dist;
    for (i = 0 ; i < ships_num; i++) {
        dist = abs((ships+i)->x - fire->x) + abs(((ships+i)->y - fire->y));
        if (dist == 0) {
            swap(&ships[i], &ships[ships_num-1]);
            min_distance = 0;
            break;
        } else if ( dist < min_distance) {
            min_distance = dist;
        }
    }

     score = 1000 - min_distance*100;
     if (score < 0 )
         return 0 ;
     else 
         return score;

}
int main(void)
{

    int n, m, s , r, i;
    int thisScore = 0 ,totalScore = 0;
    int sinkShips = 0;
    pair_t *ships, *fires;
    scanf("%d%d%d%d", &n, &m ,&s,&r);

    ships = malloc(sizeof(pair_t) * s);
    memset(ships, 0, sizeof(pair_t) * s);
    fires = malloc(sizeof(pair_t) * r);
    memset(fires, 0, sizeof(pair_t) * r);

    for(i = 0; i < s; i++) {
        scanf("%d%d", &ships[i].x, &ships[i].y);
    }

    for(i = 0; i < r; i++) {
        scanf("%d  %d", &fires[i].x, &fires[i].y);
        if ((thisScore = getPoints(ships, (s - sinkShips), &fires[i])) == 1000)
            sinkShips ++;
        totalScore += thisScore;
    }

    printf("%d/%d ships sunk. Score: %u points \n", sinkShips, s, totalScore);
    return 0;
}
