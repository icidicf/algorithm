#include <stdio.h>

static void swap(int *a, int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

static int partition(int list[],int begin, int end) {
    int pivot_idx = begin + (end - begin)/2;
    int pivot = list[pivot_idx];
    swap(&list[begin], &list[pivot_idx]);

    int i = begin + 1;
    int j = end;

    while(i <= j) {
        while((i <= end) && (list[i] <= pivot))
            i++;
        while((j >= begin) && (list[j] > pivot))
            j--;
        if(i < j)
            swap(&list[i],&list[j]);
    }

    swap(&list[begin], &list[j]);
    return j; // final pivot position
}

static void quicksort(int list[],int begin,int end) {
    if( begin < end) {
        int pivot_idx = partition(list, begin, end);
        quicksort(list, begin, pivot_idx-1);
        quicksort(list, pivot_idx+1, end);
    }
}


int main(void)
{
    int list[] = {9, 8, 5, 2, 3, 4, 7, 6, 1};
    int size = (sizeof(list)/sizeof(list[0]));
    int i ;
    quicksort(list, 0, size-1);
    printf("size is %lu %lu size %u\n", sizeof(list), sizeof(int),
            size);
    for (i = 0 ; i < size; i++)
        printf("%d   ", list[i]);

    printf("\n");

    return 0;
}
