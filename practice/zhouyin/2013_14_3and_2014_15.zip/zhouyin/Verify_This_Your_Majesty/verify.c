#include <stdio.h>

#define TRUE 1
#define FALSE 0
#define MAX_INPUT 5000

static void swap(int *a, int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

static int partition(int list[],int begin, int end) {
    int pivot_idx = begin + (end - begin)/2;
    int pivot = list[pivot_idx];
    swap(&list[begin], &list[pivot_idx]);

    int i = begin + 1;
    int j = end;

    while(i <= j) {
        while((i <= end) && (list[i] <= pivot))
            i++;
        while((j >= begin) && (list[j] > pivot))
            j--;
        if(i < j)
            swap(&list[i],&list[j]);
    }

    swap(&list[begin], &list[j]);
    return j; // final pivot position
}

static void quicksort(int list[],int begin,int end) {
    if( begin < end) {
        int pivot_idx = partition(list, begin, end);
        quicksort(list, begin, pivot_idx-1);
        quicksort(list, pivot_idx+1, end);
    }
}

static int checkdup(int list[], int end)
{
    int i;
    if (end == 0 || end ==1)
        return FALSE;
   for (i = 1 ; i <=end; i++)
       if (list[i-1] == list[i])
           return TRUE;

   return FALSE;
}

int main(void)
{
    int n, i;
    int x[MAX_INPUT], y[MAX_INPUT], sum[MAX_INPUT], diff[MAX_INPUT];

    scanf("%d", &n);

    for(i = 0 ; i < n ; i++) {
        scanf("%d%d", x+i, y+i);
        sum[i] = x[i] + y [i];
        diff[i] = x[i] - y[i];
    }

    quicksort(x,0,n-1);  
    if (checkdup(x, n-1)) {
        printf("INCORRECT\n");
        return 0;
    }

    quicksort(y,0,n-1);
    if (checkdup(y, n-1)) {
        printf("INCORRECT\n");
        return 0;
    }

    quicksort(sum,0,n-1) ;
    if (checkdup(sum, n-1)) {
        printf("INCORRECT\n");
        return 0;
    }

    quicksort(diff,0,n-1);
    if (checkdup(diff, n-1)) {
        printf("INCORRECT\n");
        return 0;
    }

    printf("CORRECT\n");
    return 0;

}
