#include <stdio.h>
int main(void)
{
    int n,i;
    int count = 0 ,temp;

    scanf("%d",&n);
    for (i = 0; i < n; i++) {
        scanf("%d", &temp);
        if (temp < 0 )
            count++;
    }
    printf("count is %d \n", count);
    return 0;
}
