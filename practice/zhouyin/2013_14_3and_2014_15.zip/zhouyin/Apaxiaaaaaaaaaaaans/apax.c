#include <stdio.h>

#define MAX_INPUT 250
static void thinname(char *input , char *output)
{

    char c;
    if (input == NULL || output == NULL)
        return ;
    while((c = *input++) != '\0') {
        while (*input == c)
            input++;
        *output++ = c; 
    }
    *output = '\0';
}

int main(void)
{
    char buf[MAX_INPUT];
    char result[MAX_INPUT];
    scanf("%s", buf);
    thinname(buf, result);
    printf("input is %s, output is %s\n", buf, result);
    return 0;
}
