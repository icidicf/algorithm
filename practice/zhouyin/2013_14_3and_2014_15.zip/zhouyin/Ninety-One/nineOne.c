#include <stdio.h>

static int nineOne(int v)
{
    if (v > 100)
        return (v -10);
    else 
        return nineOne(nineOne(v + 11));
}
int main(void)
{

    unsigned int n;
    scanf("%d", &n);
    printf("%d\n", nineOne(n));
    return 0;
}
